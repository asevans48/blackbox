from distutils.core import setup

setup(
    name='Blackbox Python API',
    version='0.1dev',
    packages=['blackbox',],
    license='Apachev2.0',
    long_description=open('ReadMe.md').read(),
)